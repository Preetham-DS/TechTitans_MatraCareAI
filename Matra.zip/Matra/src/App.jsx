import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import RiskForm from './components/RiskForm';
import RiskResult from './components/RiskResult';
import Explanation from './components/Explanation';
import EmergencyAlert from './components/EmergencyAlert';
import Web3UI from './components/Web3UI';
import Footer from './components/Footer';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import { Loader2 } from 'lucide-react';
import { calculateMaternalRisk } from './utils/riskEngine';

function App() {
  const [user, setUser] = useState(null);
  const [showAuth, setShowAuth] = useState(false);
  const [currentView, setCurrentView] = useState('home'); // 'home', 'dashboard'

  const [assessmentData, setAssessmentData] = useState(null);
  const [riskLevel, setRiskLevel] = useState(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const handleLoginClick = () => {
    setShowAuth(true);
  };

  const handleStartAssessment = () => {
    if (!user) {
      setShowAuth(true);
      return;
    }
    setCurrentView('home');
    setTimeout(() => {
      document.getElementById('assessment')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleLogin = (userData) => {
    setUser(userData);
    setShowAuth(false);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('home');
    setAssessmentData(null);
    setRiskLevel(null);
  };

  const calculateRisk = (data) => {
    setIsCalculating(true);
    setAssessmentData(null);
    setRiskLevel(null);

    // Fake delay for realism
    setTimeout(() => {
      // Use the external Risk Engine module
      const result = calculateMaternalRisk(data);

      setRiskLevel(result.level);
      setAssessmentData(data);
      setIsCalculating(false);
      
      // Scroll to result after a short delay to allow render
      setTimeout(() => {
        document.getElementById('result-section')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);

    }, 1500); // 1.5s simulation delay
  };

  const handleReset = () => {
    setAssessmentData(null);
    setRiskLevel(null);
    document.getElementById('assessment')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col relative">
      <Navbar 
        user={user} 
        onLoginClick={handleLoginClick} 
        onLogout={handleLogout}
        onStartAssessment={handleStartAssessment}
        onViewChange={(view) => setCurrentView(view)}
      />
      
      <Auth 
        isOpen={showAuth} 
        onClose={() => setShowAuth(false)} 
        onLogin={handleLogin} 
      />
      
      <main className="flex-grow">
        {currentView === 'home' ? (
          <>
            <Hero onStartAssessment={handleStartAssessment} />

            <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto" id="assessment">
              {!user ? (
                <div className="text-center py-12 bg-primary-light/50 rounded-3xl border border-primary-light fade-in">
                  <h3 className="text-2xl font-bold text-gray-800 mb-4">Please log in to start your assessment</h3>
                  <button 
                    onClick={handleLoginClick}
                    className="bg-primary-dark hover:bg-primary-dark/90 text-white px-8 py-3 rounded-full text-lg font-semibold shadow-lg transition-all"
                  >
                    Login / Sign Up
                  </button>
                </div>
              ) : (
                <>
                  {!isCalculating && !riskLevel && (
                    <div className="fade-in">
                      <RiskForm onCalculate={calculateRisk} />
                    </div>
                  )}

                  {isCalculating && (
                    <div className="flex flex-col items-center justify-center py-20 fade-in">
                      <Loader2 className="w-16 h-16 text-primary-dark animate-spin mb-4" />
                      <p className="text-xl font-medium text-gray-600 animate-pulse">Analyzing your symptoms securely...</p>
                    </div>
                  )}

                  {riskLevel && !isCalculating && (
                    <div id="result-section" className="space-y-8 pt-8">
                      <EmergencyAlert isHighRisk={riskLevel === 'HIGH'} />
                      <RiskResult level={riskLevel} onReset={handleReset} />
                      <Explanation data={assessmentData} />
                    </div>
                  )}
                </>
              )}
            </section>

            <section className="py-12 px-4 sm:px-6 lg:px-8">
              <Web3UI />
            </section>
          </>
        ) : (
          <Dashboard user={user} onStartNew={() => setCurrentView('home')} />
        )}
      </main>

      <Footer />
    </div>
  );
}

export default App;
