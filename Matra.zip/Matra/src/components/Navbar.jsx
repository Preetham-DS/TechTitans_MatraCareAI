import React from 'react';
import { HeartPulse, Menu } from 'lucide-react';

const Navbar = ({ user, onLoginClick, onLogout, onStartAssessment, onViewChange }) => {
  return (
    <nav className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-primary-light shadow-sm">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <HeartPulse className="h-8 w-8 text-primary-dark" />
            <span className="text-xl font-bold text-gray-800 tracking-tight">MatraCare</span>
          </div>

          {/* Desktop Links */}
          <div className="hidden md:flex space-x-8 items-center">
            <a href="#" className="text-gray-600 hover:text-primary-dark font-medium transition-colors">Home</a>
            <a href="#assessment" className="text-gray-600 hover:text-primary-dark font-medium transition-colors">Check Risk</a>
            <a href="#" className="text-gray-600 hover:text-primary-dark font-medium transition-colors">About</a>
            
            {user ? (
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => onViewChange('dashboard')}
                  className="text-gray-600 hover:text-primary-dark font-medium transition-colors"
                >
                  Dashboard
                </button>
                <span className="font-semibold text-gray-700 bg-primary-light px-3 py-1 rounded-full text-sm">
                  Hi, {user.name.split(' ')[0]}
                </span>
                <button 
                  onClick={onLogout}
                  className="text-gray-500 hover:text-gray-800 text-sm font-medium transition-colors"
                >
                  Logout
                </button>
                <button 
                  onClick={() => {
                    onViewChange('home');
                    onStartAssessment();
                  }}
                  className="bg-primary-dark hover:bg-primary-dark/90 text-white px-5 py-2 rounded-full font-semibold shadow-md transition-all hover:shadow-lg transform hover:-translate-y-0.5"
                >
                  Start Assessment
                </button>
              </div>
            ) : (
              <button 
                onClick={onLoginClick}
                className="bg-primary-dark hover:bg-primary-dark/90 text-white px-5 py-2 rounded-full font-semibold shadow-md transition-all hover:shadow-lg transform hover:-translate-y-0.5"
              >
                Login to Start
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button className="text-gray-600 hover:text-primary-dark">
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
