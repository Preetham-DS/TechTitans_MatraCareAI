import React, { useState } from 'react';
import { Activity, AlertCircle, Heart, Thermometer } from 'lucide-react';

const SYMPTOMS = [
  { id: 'bleeding', label: 'Bleeding', icon: <AlertCircle className="w-4 h-4" /> },
  { id: 'dizziness', label: 'Dizziness', icon: <Activity className="w-4 h-4" /> },
  { id: 'pain', label: 'Severe Pain', icon: <Heart className="w-4 h-4" /> },
  { id: 'fever', label: 'Fever', icon: <Thermometer className="w-4 h-4" /> },
];

const RiskForm = ({ onCalculate }) => {
  const [age, setAge] = useState('');
  const [selectedSymptoms, setSelectedSymptoms] = useState([]);
  const [highBP, setHighBP] = useState(false);
  const [diabetes, setDiabetes] = useState(false);
  const [prevComplications, setPrevComplications] = useState(false);

  const toggleSymptom = (id) => {
    setSelectedSymptoms(prev => 
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onCalculate({
      age: parseInt(age) || 0,
      symptoms: selectedSymptoms,
      highBP,
      diabetes,
      prevComplications
    });
  };

  return (
    <div id="assessment" className="max-w-2xl mx-auto bg-white rounded-3xl p-6 md:p-10 shadow-xl border border-primary-light">
      <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Health Assessment</h2>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        
        {/* Age Input */}
        <div>
          <label className="block text-gray-700 font-semibold mb-2">How old are you?</label>
          <input 
            type="number" 
            value={age}
            onChange={(e) => setAge(e.target.value)}
            className="w-full text-lg p-4 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-primary-dark focus:border-transparent outline-none transition-all"
            placeholder="e.g. 28"
            required
            min="10"
            max="80"
          />
        </div>

        {/* Symptoms Chips */}
        <div>
          <label className="block text-gray-700 font-semibold mb-3">Are you experiencing any of these?</label>
          <div className="flex flex-wrap gap-3">
            {SYMPTOMS.map((symptom) => {
              const isSelected = selectedSymptoms.includes(symptom.id);
              return (
                <button
                  type="button"
                  key={symptom.id}
                  onClick={() => toggleSymptom(symptom.id)}
                  className={`flex items-center space-x-2 px-5 py-3 rounded-full transition-all text-sm font-medium border ${
                    isSelected 
                      ? 'bg-primary-dark text-white border-primary-dark shadow-md' 
                      : 'bg-white text-gray-600 border-gray-200 hover:border-primary-dark hover:bg-primary-light'
                  }`}
                >
                  {symptom.icon}
                  <span>{symptom.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Medical History */}
        <div>
          <label className="block text-gray-700 font-semibold mb-3">Medical History (Check all that apply)</label>
          <div className="space-y-3 bg-gray-50 p-5 rounded-2xl border border-gray-100">
            <label className="flex items-center space-x-3 cursor-pointer">
              <input 
                type="checkbox" 
                checked={highBP}
                onChange={(e) => setHighBP(e.target.checked)}
                className="w-5 h-5 text-primary-dark rounded focus:ring-primary-dark border-gray-300"
              />
              <span className="text-gray-700">High Blood Pressure</span>
            </label>
            <label className="flex items-center space-x-3 cursor-pointer">
              <input 
                type="checkbox" 
                checked={diabetes}
                onChange={(e) => setDiabetes(e.target.checked)}
                className="w-5 h-5 text-primary-dark rounded focus:ring-primary-dark border-gray-300"
              />
              <span className="text-gray-700">Diabetes</span>
            </label>
            <label className="flex items-center space-x-3 cursor-pointer">
              <input 
                type="checkbox" 
                checked={prevComplications}
                onChange={(e) => setPrevComplications(e.target.checked)}
                className="w-5 h-5 text-primary-dark rounded focus:ring-primary-dark border-gray-300"
              />
              <span className="text-gray-700">Previous Pregnancy Complications</span>
            </label>
          </div>
        </div>

        <button 
          type="submit"
          className="w-full bg-primary-dark hover:bg-primary-dark/90 text-white py-4 rounded-2xl text-lg font-bold shadow-lg transition-all hover:shadow-xl transform hover:-translate-y-0.5"
        >
          Check My Risk
        </button>
      </form>
    </div>
  );
};

export default RiskForm;
