import React, { useState } from 'react';
import { Clock, Calendar, Activity, ShieldAlert, CheckCircle2, AlertTriangle, Filter } from 'lucide-react';

const DUMMY_HISTORY = [
  { id: 1, date: '2023-10-15', riskLevel: 'LOW', symptoms: ['None'], score: 0 },
  { id: 2, date: '2023-11-20', riskLevel: 'MEDIUM', symptoms: ['Dizziness', 'Pain'], score: 4 },
  { id: 3, date: '2023-12-05', riskLevel: 'LOW', symptoms: ['None'], score: 1 },
  { id: 4, date: '2024-01-10', riskLevel: 'HIGH', symptoms: ['Bleeding', 'Fever'], score: 7 },
  { id: 5, date: '2024-02-18', riskLevel: 'MEDIUM', symptoms: ['High BP'], score: 3 },
];

const Dashboard = ({ user, onStartNew }) => {
  const [filter, setFilter] = useState('ALL');

  const filteredHistory = DUMMY_HISTORY.filter(record => 
    filter === 'ALL' ? true : record.riskLevel === filter
  );

  const getRiskIcon = (level) => {
    switch (level) {
      case 'LOW': return <CheckCircle2 className="w-5 h-5 text-success" />;
      case 'MEDIUM': return <AlertTriangle className="w-5 h-5 text-warning" />;
      case 'HIGH': return <ShieldAlert className="w-5 h-5 text-danger" />;
      default: return null;
    }
  };

  const getRiskColor = (level) => {
    switch (level) {
      case 'LOW': return 'bg-success/10 text-success-700 border-success/20';
      case 'MEDIUM': return 'bg-warning/10 text-warning-700 border-warning/20';
      case 'HIGH': return 'bg-danger/10 text-danger-700 border-danger/20';
      default: return 'bg-gray-100';
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12 fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-gray-800">
            Welcome back, <span className="gradient-text">{user?.name || 'Jane'}</span>
          </h2>
          <p className="text-gray-500 mt-1">Here is a summary of your past risk assessments.</p>
        </div>
        <button 
          onClick={onStartNew}
          className="btn-press bg-primary-dark hover:bg-primary-dark/90 text-white px-6 py-3 rounded-full font-bold shadow-lg transition-all hover-lift"
        >
          New Assessment
        </button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm flex items-center space-x-4 card-glow slide-in-left">
          <div className="bg-primary-light p-3 rounded-2xl">
            <Activity className="w-6 h-6 text-primary-dark" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Total Assessments</p>
            <p className="text-2xl font-bold text-gray-800">{DUMMY_HISTORY.length}</p>
          </div>
        </div>
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm flex items-center space-x-4 card-glow fade-in fade-in-delay-1">
          <div className="bg-danger/10 p-3 rounded-2xl">
            <ShieldAlert className="w-6 h-6 text-danger" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">High Risk Alerts</p>
            <p className="text-2xl font-bold text-gray-800">
              {DUMMY_HISTORY.filter(h => h.riskLevel === 'HIGH').length}
            </p>
          </div>
        </div>
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm flex items-center space-x-4 card-glow slide-in-right">
          <div className="bg-gray-100 p-3 rounded-2xl">
            <Clock className="w-6 h-6 text-gray-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Last Assessment</p>
            <p className="text-xl font-bold text-gray-800">{DUMMY_HISTORY[DUMMY_HISTORY.length - 1].date}</p>
          </div>
        </div>
      </div>

      {/* History List */}
      <div className="bg-white rounded-[2rem] border border-gray-100 shadow-xl overflow-hidden">
        <div className="p-6 md:p-8 border-b border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
          <h3 className="text-xl font-bold text-gray-800 flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-primary-dark" />
            <span>Assessment History</span>
          </h3>
          
          <div className="flex items-center space-x-2 bg-gray-50 p-1.5 rounded-full border border-gray-200">
            <Filter className="w-4 h-4 text-gray-400 ml-2" />
            <select 
              value={filter} 
              onChange={(e) => setFilter(e.target.value)}
              className="bg-transparent text-sm font-medium text-gray-700 outline-none pr-4 cursor-pointer"
            >
              <option value="ALL">All Results</option>
              <option value="LOW">Low Risk</option>
              <option value="MEDIUM">Medium Risk</option>
              <option value="HIGH">High Risk</option>
            </select>
          </div>
        </div>

        <div className="max-h-[500px] overflow-y-auto p-6 md:p-8 space-y-4 bg-gray-50/50">
          {filteredHistory.length === 0 ? (
            <div className="text-center py-10 text-gray-500">
              No history records found for this filter.
            </div>
          ) : (
            filteredHistory.map((record) => (
              <div 
                key={record.id} 
                className={`flex flex-col sm:flex-row items-start sm:items-center justify-between p-5 bg-white rounded-2xl border transition-all card-glow ${getRiskColor(record.riskLevel)}`}
              >
                <div className="flex items-center space-x-4 mb-4 sm:mb-0">
                  <div className="bg-white p-2 rounded-full shadow-sm">
                    {getRiskIcon(record.riskLevel)}
                  </div>
                  <div>
                    <p className="font-bold text-gray-800">{record.date}</p>
                    <p className="text-sm text-gray-500">Symptoms: {record.symptoms.join(', ')}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 w-full sm:w-auto">
                  <span className="px-4 py-1.5 rounded-full bg-white font-bold text-sm shadow-sm flex-1 sm:flex-none text-center">
                    {record.riskLevel} RISK
                  </span>
                  <button className="text-gray-400 hover:text-primary-dark transition-colors p-2 bg-white rounded-full shadow-sm">
                    <span className="sr-only">View Details</span>
                    &rarr;
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
