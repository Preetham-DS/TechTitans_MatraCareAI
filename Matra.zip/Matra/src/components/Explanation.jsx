import React, { useState } from 'react';
import { Info, CheckCircle, ChevronDown, ChevronUp } from 'lucide-react';

const Explanation = ({ data }) => {
  const [isOpen, setIsOpen] = useState(true);

  if (!data) return null;

  return (
    <div id="details" className="max-w-2xl mx-auto bg-white rounded-3xl shadow-lg border border-gray-100 mt-8 overflow-hidden fade-in">
      {/* Header / Toggle */}
      <div 
        className="flex items-center justify-between p-6 md:px-10 md:py-8 cursor-pointer hover:bg-gray-50 transition-colors"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex items-center space-x-3">
          <Info className="w-6 h-6 text-primary-dark" />
          <h3 className="text-2xl font-bold text-gray-800">Why this result?</h3>
        </div>
        <button className="text-gray-500 focus:outline-none">
          {isOpen ? <ChevronUp className="w-6 h-6" /> : <ChevronDown className="w-6 h-6" />}
        </button>
      </div>
      
      {/* Collapsible Content */}
      {isOpen && (
        <div className="px-6 pb-6 md:px-10 md:pb-10 border-t border-gray-50 pt-6">
          <ul className="space-y-4 mb-8">
            <li className="flex items-start space-x-3">
              <div className="mt-1 bg-primary-light p-1 rounded-full"><CheckCircle className="w-4 h-4 text-primary-dark" /></div>
              <div>
                <p className="font-semibold text-gray-800">Age Factor</p>
                <p className="text-gray-600 text-sm">Age {data.age}. {data.age > 35 ? "Advanced maternal age is a known risk factor." : "Your age is within a generally lower-risk bracket."}</p>
              </div>
            </li>
            
            {data.symptoms && data.symptoms.length > 0 && (
              <li className="flex items-start space-x-3">
                <div className="mt-1 bg-primary-light p-1 rounded-full"><CheckCircle className="w-4 h-4 text-primary-dark" /></div>
                <div>
                  <p className="font-semibold text-gray-800">Symptoms</p>
                  <p className="text-gray-600 text-sm">You reported: {data.symptoms.join(', ')}. These contribute to the risk score.</p>
                </div>
              </li>
            )}

            {(data.highBP || data.diabetes || data.prevComplications) && (
              <li className="flex items-start space-x-3">
                <div className="mt-1 bg-primary-light p-1 rounded-full"><CheckCircle className="w-4 h-4 text-primary-dark" /></div>
                <div>
                  <p className="font-semibold text-gray-800">Medical History</p>
                  <p className="text-gray-600 text-sm">
                    History of {data.highBP && 'High BP'} {data.diabetes && 'Diabetes'} {data.prevComplications && 'Previous Complications'} has been factored into the assessment.
                  </p>
                </div>
              </li>
            )}
          </ul>

          <div className="bg-secondary-light p-6 rounded-2xl">
            <h4 className="font-bold text-gray-800 mb-2">What should you do?</h4>
            <p className="text-gray-700 text-sm leading-relaxed">
              Maintain a healthy diet, stay hydrated, and ensure you attend all your scheduled prenatal check-ups. 
              Always listen to your body and contact your healthcare provider if you experience any unusual symptoms.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Explanation;
