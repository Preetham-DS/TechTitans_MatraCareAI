import React from 'react';
import { CheckCircle2, AlertTriangle, ShieldAlert } from 'lucide-react';

const RiskResult = ({ level, onReset }) => {
  let bgColor, textColor, Icon, title, message;

  switch (level) {
    case 'LOW':
      bgColor = 'bg-success/10';
      textColor = 'text-success';
      Icon = CheckCircle2;
      title = 'Low Risk';
      message = 'Your pregnancy seems to be progressing well with minimal risk factors detected.';
      break;
    case 'MEDIUM':
      bgColor = 'bg-warning/10';
      textColor = 'text-warning';
      Icon = AlertTriangle;
      title = 'Medium Risk';
      message = 'We detected some factors that require attention. Please schedule a check-up with your doctor.';
      break;
    case 'HIGH':
      bgColor = 'bg-danger/10';
      textColor = 'text-danger';
      Icon = ShieldAlert;
      title = 'High Risk Detected';
      message = 'Critical risk factors identified. Immediate medical consultation is strongly advised.';
      break;
    default:
      return null;
  }

  return (
    <div className={`max-w-2xl mx-auto rounded-3xl p-8 md:p-12 text-center shadow-2xl scale-in border ${bgColor} border-${textColor}/20`}>
      <div className={`inline-flex justify-center items-center w-24 h-24 rounded-full ${bgColor} mb-6`}>
        <Icon className={`w-12 h-12 ${textColor}`} />
      </div>
      <h2 className={`text-4xl font-extrabold mb-4 ${textColor}`}>{title}</h2>
      <p className="text-xl text-gray-700 mb-8 max-w-md mx-auto">{message}</p>
      
      <div className="space-y-4">
        <button 
          onClick={() => document.getElementById('details')?.scrollIntoView({ behavior: 'smooth' })}
          className={`btn-press w-full md:w-auto px-8 py-3 rounded-full text-lg font-bold text-white shadow-lg transition-transform hover:-translate-y-1 ${
            level === 'LOW' ? 'bg-success' : level === 'MEDIUM' ? 'bg-warning' : 'bg-danger'
          }`}
        >
          View Details
        </button>
        <div className="block">
          <button 
            onClick={onReset}
            className="text-gray-500 hover:text-gray-800 font-medium underline underline-offset-4 mt-4"
          >
            Start Over
          </button>
        </div>
      </div>
    </div>
  );
};

export default RiskResult;
