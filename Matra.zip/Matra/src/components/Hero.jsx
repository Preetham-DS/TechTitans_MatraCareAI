import React from 'react';
import { ShieldCheck, Heart, Zap, Lock, Star, Quote } from 'lucide-react';

const Hero = ({ onStartAssessment }) => {
  return (
    <div>
      {/* Main Hero Section */}
      <section className="relative pt-16 pb-20 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between">
        
        {/* Text Content */}
        <div className="md:w-1/2 space-y-6 z-10 text-center md:text-left">
          <div className="inline-flex items-center space-x-2 bg-secondary-light px-4 py-2 rounded-full text-secondary-dark font-semibold text-sm fade-in">
            <ShieldCheck className="w-4 h-4" />
            <span>AI-Powered Health Assistant</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 leading-tight fade-in" style={{ animationDelay: '0.1s' }}>
            Your Pregnancy, <br/>
            <span className="gradient-text">Our Care</span>
          </h1>
          <p className="text-lg text-gray-600 max-w-md mx-auto md:mx-0 fade-in" style={{ animationDelay: '0.2s' }}>
            Check your pregnancy risk instantly using our secure AI predictor. Fast, simple, and designed to support you every step of the way.
          </p>
          <div className="fade-in pt-2" style={{ animationDelay: '0.3s' }}>
            <button 
              onClick={onStartAssessment}
              className="bg-primary-dark hover:bg-primary-dark/90 text-white px-8 py-4 rounded-full text-lg font-bold shadow-lg transition-all hover:shadow-xl transform hover:-translate-y-1 w-full md:w-auto flex items-center justify-center space-x-2 mx-auto md:mx-0"
            >
              <Heart className="w-5 h-5" />
              <span>Check My Risk Now</span>
            </button>
          </div>
        </div>

        {/* Graphic/Illustration */}
        <div className="md:w-1/2 mt-16 md:mt-0 flex justify-center fade-in" style={{ animationDelay: '0.4s' }}>
          <div className="relative w-72 h-72 md:w-96 md:h-96 bg-primary-DEFAULT rounded-full opacity-20 absolute filter blur-3xl"></div>
          <div className="float relative z-10 bg-white p-6 rounded-[3rem] shadow-xl border border-primary-light hover-lift">
            <img 
              src="https://images.unsplash.com/photo-1531983412531-1f49a365ffed?auto=format&fit=crop&w=600&q=80" 
              alt="Pregnant Woman" 
              className="w-64 h-64 md:w-80 md:h-80 object-cover rounded-[2rem]"
            />
          </div>
        </div>
      </section>

      {/* Feature Highlights / Benefits */}
      <section className="bg-white py-20 border-y border-gray-100">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl font-extrabold text-gray-900">Why choose MatraCare?</h2>
            <p className="text-gray-500 mt-4 max-w-2xl mx-auto">Our platform combines cutting-edge AI with secure technology to bring you peace of mind during your pregnancy.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-primary-light/30 p-8 rounded-3xl border border-primary-light/50 text-center fade-in card-glow">
              <div className="bg-primary-light w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Zap className="w-8 h-8 text-primary-dark" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Instant AI Analysis</h3>
              <p className="text-gray-600">Get immediate, data-driven insights on your symptoms and overall risk profile.</p>
            </div>
            
            <div className="bg-secondary-light/30 p-8 rounded-3xl border border-secondary-light/50 text-center fade-in card-glow" style={{ animationDelay: '0.1s' }}>
              <div className="bg-secondary-light w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <ShieldCheck className="w-8 h-8 text-secondary-dark" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Doctor Approved</h3>
              <p className="text-gray-600">Built using established medical guidelines to ensure reliable and safe early warnings.</p>
            </div>

            <div className="bg-success/5 p-8 rounded-3xl border border-success/10 text-center fade-in card-glow" style={{ animationDelay: '0.2s' }}>
              <div className="bg-success/20 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Lock className="w-8 h-8 text-success-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">100% Secure & Private</h3>
              <p className="text-gray-600">Your health data is encrypted and secure. We never share your personal information.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl font-extrabold text-gray-900">Loved by mothers</h2>
            <p className="text-gray-500 mt-4 max-w-2xl mx-auto">See how MatraCare is making a difference in the lives of expecting parents everywhere.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100 relative fade-in">
              <Quote className="absolute top-6 right-8 w-12 h-12 text-primary-light opacity-50" />
              <div className="flex space-x-1 mb-4">
                {[1,2,3,4,5].map(star => <Star key={star} className="w-5 h-5 text-warning fill-current" />)}
              </div>
              <p className="text-gray-700 text-lg italic mb-6 relative z-10">
                "MatraCare gave me the reassurance I needed. When I had mild pain, the assessment correctly advised me that it was a low-risk scenario, saving me an anxious trip to the ER."
              </p>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-primary-dark text-white rounded-full flex items-center justify-center font-bold text-xl">S</div>
                <div>
                  <p className="font-bold text-gray-900">Sarah Jenkins</p>
                  <p className="text-sm text-gray-500">First-time Mother</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100 relative fade-in" style={{ animationDelay: '0.1s' }}>
              <Quote className="absolute top-6 right-8 w-12 h-12 text-secondary-light opacity-50" />
              <div className="flex space-x-1 mb-4">
                {[1,2,3,4,5].map(star => <Star key={star} className="w-5 h-5 text-warning fill-current" />)}
              </div>
              <p className="text-gray-700 text-lg italic mb-6 relative z-10">
                "The interface is so friendly and calming. Being pregnant is stressful enough, but checking my symptoms on this app actually feels supportive and simple."
              </p>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-secondary-dark text-white rounded-full flex items-center justify-center font-bold text-xl">M</div>
                <div>
                  <p className="font-bold text-gray-900">Maya Patel</p>
                  <p className="text-sm text-gray-500">Expecting her second</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Hero;
