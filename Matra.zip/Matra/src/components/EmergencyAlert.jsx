import React from 'react';
import { Phone, MapPin, AlertTriangle } from 'lucide-react';

const EmergencyAlert = ({ isHighRisk }) => {
  if (!isHighRisk) return null;

  return (
    <div className="max-w-2xl mx-auto mt-6 bg-danger border-2 border-danger-700 p-6 rounded-3xl shadow-xl text-white fade-in animate-pulse shadow-danger/50 relative overflow-hidden">
      
      {/* Decorative Warning Icon Background */}
      <AlertTriangle className="absolute -right-4 -bottom-4 w-48 h-48 text-white opacity-5" />

      <div className="text-center mb-6 relative z-10 flex flex-col items-center">
        <div className="bg-white/20 p-4 rounded-full mb-4">
          <AlertTriangle className="w-10 h-10 text-white" />
        </div>
        <h3 className="text-3xl font-black mb-2 uppercase tracking-wide">Immediate Action Recommended</h3>
        <p className="text-danger-100 font-medium text-lg">Your symptoms suggest you should seek medical assistance promptly. Do not ignore severe symptoms.</p>
      </div>
      
      <div className="flex flex-col sm:flex-row justify-center gap-4 relative z-10">
        <button className="flex items-center justify-center space-x-2 bg-white text-danger px-8 py-4 rounded-full font-bold shadow hover:bg-gray-50 transition-colors">
          <Phone className="w-6 h-6" />
          <span>Call Doctor Now</span>
        </button>
        <button className="flex items-center justify-center space-x-2 bg-danger-800 text-white px-8 py-4 rounded-full font-bold shadow hover:bg-danger-900 transition-colors border border-white/20">
          <MapPin className="w-6 h-6" />
          <span>Find Nearby Hospital</span>
        </button>
      </div>
    </div>
  );
};

export default EmergencyAlert;
