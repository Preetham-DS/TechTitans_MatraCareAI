/**
 * Maternal Risk Calculation Engine
 * Reusable logic function to simulate an intelligent decision-making system.
 */

export const calculateMaternalRisk = (data) => {
  console.log("=== RISK ENGINE: Starting Calculation ===");
  console.log("Input Data:", data);

  let score = 0;
  let breakdown = {
    agePoints: 0,
    symptomPoints: 0,
    historyPoints: 0
  };

  // 1. Edge Case Handling
  if (!data || typeof data.age !== 'number') {
    console.warn("RISK ENGINE: Invalid data provided. Defaulting to LOW risk.");
    return { level: 'LOW', score: 0, breakdown };
  }

  // 2. Age-based scoring
  if (data.age < 18) {
    score += 2;
    breakdown.agePoints = 2;
    console.log("RISK ENGINE: Added 2 points for age < 18.");
  } else if (data.age > 35) {
    score += 2;
    breakdown.agePoints = 2;
    console.log("RISK ENGINE: Added 2 points for advanced maternal age (> 35).");
  }

  // 3. Symptom-based scoring
  if (data.symptoms && Array.isArray(data.symptoms)) {
    if (data.symptoms.includes('bleeding')) {
      score += 4;
      breakdown.symptomPoints += 4;
      console.log("RISK ENGINE: Added 4 points for bleeding.");
    }
    if (data.symptoms.includes('pain')) {
      score += 2;
      breakdown.symptomPoints += 2;
      console.log("RISK ENGINE: Added 2 points for severe pain.");
    }
    if (data.symptoms.includes('fever')) {
      score += 2;
      breakdown.symptomPoints += 2;
      console.log("RISK ENGINE: Added 2 points for fever.");
    }
    if (data.symptoms.includes('dizziness')) {
      score += 1;
      breakdown.symptomPoints += 1;
      console.log("RISK ENGINE: Added 1 point for dizziness.");
    }
  }

  // 4. Medical history scoring
  if (data.highBP) {
    score += 3;
    breakdown.historyPoints += 3;
    console.log("RISK ENGINE: Added 3 points for High BP.");
  }
  if (data.diabetes) {
    score += 2;
    breakdown.historyPoints += 2;
    console.log("RISK ENGINE: Added 2 points for Diabetes.");
  }
  if (data.prevComplications) {
    score += 2;
    breakdown.historyPoints += 2;
    console.log("RISK ENGINE: Added 2 points for Previous Complications.");
  }

  // 5. Risk categorization (Low/Medium/High)
  let level = 'LOW';
  if (score >= 6) {
    level = 'HIGH';
  } else if (score >= 3) {
    level = 'MEDIUM';
  }

  console.log(`=== RISK ENGINE: Calculation Complete | Total Score: ${score} | Level: ${level} ===`);
  
  return { level, score, breakdown };
};
